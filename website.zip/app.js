import {siteConfig} from './config.js';
import {roomScreens,nextRoom} from './room-shuffle.js';
import {initialLocale,loadCopy,rememberLocale,localizedLink} from './i18n.js';
const textNodes=[...document.querySelectorAll('[data-i18n]')];
let locale='en', copy=await loadCopy('en'), localeRequest=0;
let screen='home',request=0;
const t=key=>copy[key];
const languagePicker=document.querySelector('#site-language');
const status=document.querySelector('#live-status');
const screenshot=document.querySelector('#app-screenshot');
const decorateButton=document.querySelector('#decorate-room');
const dialog=document.querySelector('#download-dialog');
function setText(element,value){
  const lines=value.split('\n');
  element.replaceChildren(...lines.flatMap((line,index)=>index?[document.createElement('br'),document.createTextNode(line+' ')]:[document.createTextNode(line+' ')]));
}
async function setLocale(next){
  const ticket=++localeRequest;
  try {
    const nextCopy=await loadCopy(next);
    if(ticket!==localeRequest)return;
    locale=next;copy=nextCopy;document.documentElement.lang=locale;
    for(const element of textNodes)setText(element,t(element.dataset.i18n));
    for(const element of document.querySelectorAll('[data-i18n-aria]'))element.setAttribute('aria-label',t(element.dataset.i18nAria));
    for(const element of document.querySelectorAll('[data-i18n-alt]'))element.alt=t(element.dataset.i18nAlt);
    screenshot.alt=t('screen'+screen[0].toUpperCase()+screen.slice(1)+'Alt');
    languagePicker.value=locale;
    document.title=t('pageTitle');
    for(const name of ['description','og:description'])document.querySelector(`[${name==='description'?'name':'property'}="${name}"]`)?.setAttribute('content',t('pageDescription'));
    document.querySelector('[property="og:title"]')?.setAttribute('content',t('pageTitle'));
    for(const link of document.querySelectorAll('[data-privacy]'))link.href=localizedLink(siteConfig.privacyURL,locale);
    if(siteConfig.appStoreURL)for(const element of document.querySelectorAll('[data-i18n="navGet"],[data-i18n="closingCTA"]'))setText(element,t('navDownload'));
    rememberLocale(locale);
  } catch {
    if(ticket!==localeRequest)return;
    languagePicker.value=locale;
    status.textContent=t('languageError');
  }
}
languagePicker.addEventListener('change',()=>setLocale(languagePicker.value));
decorateButton.addEventListener('click',async()=>{
  if(decorateButton.disabled)return;
  const next=nextRoom(screen);const ticket=++request;
  decorateButton.disabled=true;decorateButton.setAttribute('aria-busy','true');
  const src=`screens/${next}.webp`;const image=new Image();image.src=src;
  try{
    await image.decode();if(ticket!==request)return;
    screen=next;screenshot.src=src;screenshot.alt=t('screen'+next[0].toUpperCase()+next.slice(1)+'Alt');
    screenshot.dataset.view=next;
    if(!matchMedia('(prefers-reduced-motion: reduce)').matches)screenshot.animate(
      [{opacity:.35,transform:'translateY(4px)'},{opacity:1,transform:'translateY(0)'}],
      {duration:320,easing:'ease-out'});
    status.textContent=t('screenChanged')+' '+t('screen'+next[0].toUpperCase()+next.slice(1));
  }catch{if(ticket===request)status.textContent=t('screenError')}
  finally{if(ticket===request){decorateButton.disabled=false;decorateButton.removeAttribute('aria-busy')}}
});

for(const link of document.querySelectorAll('[data-terms]'))link.href=siteConfig.termsURL;
for(const button of document.querySelectorAll('[data-download]'))button.addEventListener('click',()=>{if(siteConfig.appStoreURL)location.assign(siteConfig.appStoreURL);else dialog.showModal()});
dialog.addEventListener('click',event=>{const b=dialog.getBoundingClientRect();if(event.target===dialog&&(event.clientX<b.left||event.clientX>b.right||event.clientY<b.top||event.clientY>b.bottom))dialog.close()});
dialog.addEventListener('close',()=>{if(dialog.returnValue==='explore')document.querySelector('#preview').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'center'})});
await setLocale(initialLocale());
