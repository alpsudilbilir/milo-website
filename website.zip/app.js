import {siteConfig} from './config.js';
import {roomScreens,nextRoom} from './room-shuffle.js';
const textNodes=[...document.querySelectorAll('[data-i18n]')];
const originalText=element=>[...element.childNodes].map(node=>node.nodeName==='BR'?'\n':node.textContent).join('');
const english=Object.fromEntries(textNodes.map(element=>[element.dataset.i18n,originalText(element)]));
for(const element of document.querySelectorAll('[data-i18n-aria]'))english[element.dataset.i18nAria]=element.getAttribute('aria-label');
for(const element of document.querySelectorAll('[data-i18n-alt]'))english[element.dataset.i18nAlt]=element.alt;
const turkish = {
  skip: 'İçeriğe geç', navigation: 'Ana menü', navThings: 'küçük güzellikler', navRoom: 'senin odan', navFAQ: 'merak ettiklerin', navGet: 'Yakında iPhone’da',
  eyebrow: 'biraz daha tatlı bir uygulama engelleyici', heroLine1: 'Daha az kaydır.', heroLine2: 'Küçük zaferler kazan.',
  heroDescription: 'Biraz odak. Birkaç palamut. Mobilya seçimlerine fazlasıyla önem veren bir tilki. Telefonunu bırakmanın daha cozy haliyle tanış.',
  heroCTA: 'Odak arkadaşınla tanış', heroSecondary: 'Biraz etrafa bak', heroNote: 'iPhone için. Sana iyi gelen anlar için.',
  miloNote: '“yapılacaklar listen aradı.\nelimizden geleni yapıyoruz dedim.”', sceneNote: 'dönüp geleceğin küçük bir oda',
  heroBottom: 'Daha sakin bir telefon. Sana ait bir oda.', explore: 'Milo’yu keşfet',
  thingsEyebrow: 'küçük adımlar. daha yumuşak günler.', thingsTitle: 'İyi alışkanlıklar\nödev gibi hissettirmesin.',
  thingsDescription: 'Milo, yapmak istediklerine yer açar.\nBir odak seansı, bir küçük zaferle.',
  feeds: 'bitmeyen akışlar', videos: 'bir video daha', notNow: 'şimdi değil. yapabilirsin.', justThis: 'sadece bu an', wellEarned: 'hak ettin.',
  step1Title: 'Dikkat dağıtanları kapıda bırak.', step1Description: 'Engellemek istediğin uygulamaları, kategorileri ve siteleri seç. Günlük bir kullanım hakkı belirle ya da odaklanırken onları dışarıda tut.',
  step2Title: 'Kendi ritmine yerleş.', step2Description: 'Beş dakika mı, uzun bir öğleden sonra mı? 5–180 dakikalık bir odak süresi ve niyet seç. Her seferinde bir seansla ilerle.',
  step3Title: 'Küçük zaferlerin yuvaya dönüşsün.', step3Description: 'Tamamlanan seanslar palamut kazandırır ve Milo’nun kalplerini yenilemeye yardımcı olur. Palamutları yeni bir koltuğa, güzel bir halıya veya oda için minik bir hediyeye dönüştür.',
  roomEyebrow: 'sadece ana ekran değil, bir yuva', roomTitle: 'Senin odağın.\nMilo’nun mutlu köşesi.',
  roomDescription: 'Güneşli bir köşe? Leylak rengi bir hayal? Tam da sana göre bir şey? Milo’nun odasını sevdiğin küçük şeylerle doldur.', roomCTA: 'Yukarıda başka bir oda dene',
  decorAlt: 'Milo’nun odasından birkaç dekoratif eşya', decorChair: 'rahat bir köşe', decorBooks: 'bir bölüm daha', decorRug: 'yumuşacık bir şey', decorPlant: 'biraz canlılık', decorLamp: 'sıcak bir karşılama',
  decorNote: 'Normal dekorlar kazanılan palamutlarla alınır. Özel Plus dekorları Milo Pro’ya dahildir.',
  readingAlt: 'Patilerini başının arkasına koyup koltuğa yayılmış Milo', readingNote: 'işinin başında.\nçoğunlukla oturarak.',
  companionEyebrow: 'milo’yla tanış', companionTitle: 'Sen odaklan.\nO denetlesin.',
  companionDescription: 'Seansları sen tamamlar, palamutları sen kazanır, odayı sen döşersin. Milo’nun ruh hâli ilerlemene eşlik eder. Emek senin. Övgüyü kendine ayırmış.',
  faqEyebrow: 'aklına takılabilecek birkaç şey', faqTitle: 'Taşınmadan\nönce.', faqNote: 'Milo küçük yazıları okudu.\nçoğunu.',
  faq1Question: 'Milo tam olarak neyi engelliyor?', faq1Answer: 'Korunacak uygulamaları, kategorileri ve siteleri sen seçersin. Milo, izninle Apple’ın Ekran Süresi teknolojisini kullanarak bunları odak sırasında veya ortak günlük kullanım hakkın bittiğinde engeller.',
  faq2Question: 'Milo’yu abonelik olmadan kullanabilir miyim?', faq2Answer: 'Evet. Temel odak seansları, günlük kullanım hakkı ve palamut dekor mağazası abonelik olmadan kullanılabilir. Milo Pro; özel odalar ve Plus dekorları, ayrıntılı istatistikler, geleceğe seans planlama ve hatırlatıcılar ekler.',
  faq3Question: 'Palamutları nasıl kazanırım?', faq3Answer: 'Odak seanslarını tamamlayarak palamut kazanır, sonra normal oda dekorlarına harcarsın. Satın aldıkların koleksiyonunda kalır; favorilerin arasında geçiş yapabilirsin. Pro erişimi ve palamutla alınan eşyalar ayrıdır.',
  faq4Question: 'Hesap açmam gerekiyor mu?', faq4Answer: 'Hesap girişi gerekmez. Uygulama engelleme için Ekran Süresi izni gerekir. Satın alımlar ve abonelikler Apple hesabını kullanır; uygun satın alımları uygulama içinde geri yükleyebilirsin.',
  closingEyebrow: 'biraz daha az telefon. biraz daha çok sen.', closingTitle: 'Önemli şeylere\nküçük bir yer aç.', closingCTA: 'Milo’ya merhaba de', closingNote: 'Bir sonraki küçük zaferin, biraz yer açmakla başlar.',
  footerNote: 'Küçük bir tilki. Daha tatlı bir odak.', legal: 'Yasal bağlantılar', privacy: 'Gizlilik', terms: 'Koşullar', close: 'Kapat',
  launchTitle: 'Yakında App Store’da', launchDescription: 'Milo henüz indirilemiyor. O zamana kadar kendine göre bir oda bul.', launchCTA: 'Odaları keşfet',
  supportPrompt: 'Yardıma mı ihtiyacın var?', support: 'Destek al'
};

Object.assign(english,{chooseScreen:'Explore the app',screenHomeAlt:'Milo’s actual home screen',screenFocusAlt:'Milo’s focus-completion screen; illustrative session in the app',screenDecorAlt:'Milo’s actual decor catalog',screenChanged:'Showing',screenError:'That screen couldn’t load. Please try again.'});
Object.assign(turkish,{chooseScreen:'Uygulama ekranlarını keşfet',screenHome:'odası',screenFocus:'küçük bir zafer',screenDecor:'kendine göre döşe',screenHomeAlt:'Milo’nun gerçek ana ekranı',screenFocusAlt:'Milo’nun odak bitiş ekranı; uygulamadaki örnek seans',screenDecorAlt:'Milo’nun gerçek dekor kataloğu',screenChanged:'Gösterilen',screenError:'Ekran yüklenemedi. Tekrar deneyebilirsin.',roomCTA:'Yukarıda uygulama ekranlarına bak'});
export const translations={en:english,tr:turkish};
Object.assign(english,{decorateRoom:'Decorate',screenHome:'First room',screenCoastal:'Seaside',screenLilac:'Lilac',screenCottage:'Cottage',screenStudy:'Study',screenCabin:'Cabin',screenMoonlight:'Moonlight'});
Object.assign(turkish,{decorateRoom:'Yeniden döşe',screenHome:'İlk oda',screenCoastal:'Sahil',screenLilac:'Leylak',screenCottage:'Kır evi',screenStudy:'Çalışma odası',screenCabin:'Kulübe',screenMoonlight:'Ay ışığı'});
for(const id of roomScreens){
 const key='screen'+id[0].toUpperCase()+id.slice(1);
 english[key+'Alt']='Milo’s actual room screen: '+english[key];
 turkish[key+'Alt']='Milo’nun gerçek oda ekranı: '+turkish[key];
}
let locale='en',screen='home',request=0;
const outlineKeys=new Set(['heroLine1','heroLine2','thingsTitle','roomTitle','companionTitle','faqTitle','closingTitle','miloNote','sceneNote']);
const t=key=>translations[locale][key]??english[key]??key;
const status=document.querySelector('#live-status');
const screenshot=document.querySelector('#app-screenshot');
const decorateButton=document.querySelector('#decorate-room');
const dialog=document.querySelector('#download-dialog');
function setText(element,value){
  if(outlineKeys.has(element.dataset.i18n)){
    const img=new Image();img.src=`type/landing/${locale}-${element.dataset.i18n}.svg`;img.alt='';img.className='native-type';img.setAttribute('aria-hidden','true');
    const text=document.createElement('span');text.className='sr-only';text.textContent=value;
    element.replaceChildren(img,text);return;
  }
  const lines=value.split('\n');
  element.replaceChildren(...lines.flatMap((line,index)=>index?[document.createElement('br'),document.createTextNode(line+' ')]:[document.createTextNode(line+' ')]));
}
function setLocale(next){
  if(!translations[next])return;locale=next;document.documentElement.lang=locale;
  for(const element of textNodes)setText(element,t(element.dataset.i18n));
  for(const element of document.querySelectorAll('[data-i18n-aria]'))element.setAttribute('aria-label',t(element.dataset.i18nAria));
  for(const element of document.querySelectorAll('[data-i18n-alt]'))element.alt=t(element.dataset.i18nAlt);
  screenshot.alt=t('screen'+screen[0].toUpperCase()+screen.slice(1)+'Alt');
  for(const button of document.querySelectorAll('[data-locale]'))button.setAttribute('aria-pressed',String(button.dataset.locale===locale));
  document.title=locale==='tr'?'Milo: The App Blocker — Odak için küçük bir yer':'Milo: The App Blocker — A little room for focus';
  try{localStorage.setItem('milo.site.locale',locale)}catch{}
}
for(const button of document.querySelectorAll('[data-locale]'))button.addEventListener('click',()=>setLocale(button.dataset.locale));
decorateButton.addEventListener('click',async()=>{
  if(decorateButton.disabled)return;
  const next=nextRoom(screen);const ticket=++request;
  decorateButton.disabled=true;decorateButton.setAttribute('aria-busy','true');
  const src=`screens/${next}.webp`;const image=new Image();image.src=src;
  try{
    await image.decode();if(ticket!==request)return;
    screen=next;screenshot.src=src;screenshot.alt=t('screen'+next[0].toUpperCase()+next.slice(1)+'Alt');
    screenshot.dataset.view=next;
    if(!matchMedia('(prefers-reduced-motion: reduce)').matches)screenshot.animate(
      [{opacity:.35,transform:'translateY(4px)'},{opacity:1,transform:'translateY(0)'}],
      {duration:320,easing:'ease-out'});
    status.textContent=t('screenChanged')+' '+t('screen'+next[0].toUpperCase()+next.slice(1));
  }catch{if(ticket===request)status.textContent=t('screenError')}
  finally{if(ticket===request){decorateButton.disabled=false;decorateButton.removeAttribute('aria-busy')}}
});
for(const link of document.querySelectorAll('[data-privacy]'))link.href=siteConfig.privacyURL;
for(const link of document.querySelectorAll('[data-terms]'))link.href=siteConfig.termsURL;
for(const button of document.querySelectorAll('[data-download]'))button.addEventListener('click',()=>{if(siteConfig.appStoreURL)location.assign(siteConfig.appStoreURL);else dialog.showModal()});
dialog.addEventListener('click',event=>{const b=dialog.getBoundingClientRect();if(event.target===dialog&&(event.clientX<b.left||event.clientX>b.right||event.clientY<b.top||event.clientY>b.bottom))dialog.close()});
dialog.addEventListener('close',()=>{if(dialog.returnValue==='explore')document.querySelector('#preview').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'center'})});
try{setLocale(localStorage.getItem('milo.site.locale')||'en')}catch{setLocale('en')}
