export const roomScreens=['home','coastal','lilac','cottage','study','cabin','moonlight'];
// Pick a complete native app capture, never synthetic combinations of assets.
export function nextRoom(current,random=Math.random){
  const alternatives=roomScreens.filter(id=>id!==current);
  return alternatives[Math.floor(random()*alternatives.length)];
}
