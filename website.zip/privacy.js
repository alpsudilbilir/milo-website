const copy={en:{skip:'Skip to content',back:'Back to Milo',terms:'Terms',title:'Milo — Privacy Policy'},tr:{skip:'İçeriğe geç',back:'Milo’ya dön',terms:'Koşullar',title:'Milo — Gizlilik Politikası'}};
function setPolicyLocale(locale){
 if(!copy[locale])locale='en';
 document.documentElement.lang=locale;
 document.title=copy[locale].title;
 for(const article of document.querySelectorAll('[data-policy-language]'))article.hidden=article.dataset.policyLanguage!==locale;
 for(const node of document.querySelectorAll('[data-policy-ui]'))node.textContent=copy[locale][node.dataset.policyUi];
 for(const button of document.querySelectorAll('[data-policy-locale]'))button.setAttribute('aria-pressed',String(button.dataset.policyLocale===locale));
 try{localStorage.setItem('milo.site.locale',locale)}catch{}
}
for(const button of document.querySelectorAll('[data-policy-locale]'))button.addEventListener('click',()=>setPolicyLocale(button.dataset.policyLocale));
try{setPolicyLocale(localStorage.getItem('milo.site.locale')||'en')}catch{setPolicyLocale('en')}
