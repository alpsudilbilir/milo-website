import {initialLocale,loadCopy,rememberLocale,localizedLink} from './i18n.js';
const picker=document.querySelector('#site-language');
const response=await fetch(new URL('./privacy-locales.json',import.meta.url));
if(!response.ok)throw new Error('Privacy translations could not load');
const policies=await response.json();
let locale='en',copy=await loadCopy('en'),request=0;
function policyArticle(next,policy){
 let article=document.querySelector(`[data-policy-language="${next}"]`);
 if(article)return article;
 article=document.createElement('article');article.dataset.policyLanguage=next;article.hidden=true;
 const title=document.createElement('h1');title.id=`privacy-${next}-title`;title.textContent=policy.title;
 article.setAttribute('aria-labelledby',title.id);
 const brand=document.createElement('span');brand.className='eyebrow';brand.textContent='Milo: The App Blocker';
 const updated=document.createElement('p');updated.className='policy-updated';updated.textContent=policy.updated;
 article.append(brand,title,updated);
 for(const item of policy.sections){
  const section=document.createElement('section');const heading=document.createElement('h2');heading.textContent=item.heading;section.append(heading);
  for(const block of item.blocks){
   const node=document.createElement(block.tag);
   // Packaged policy translations contain only the existing fixed links.
   if(block.tag==='p')node.innerHTML=block.html;
   else for(const text of block.items){const li=document.createElement('li');li.textContent=text;node.append(li)}
   section.append(node);
  }
  article.append(section);
 }
 document.querySelector('#privacy-content').append(article);
 return article;
}
async function setPolicyLocale(next){
 const ticket=++request;
 try{
  const nextCopy=await loadCopy(next);if(ticket!==request)return;
  const policy=policies[next];if(!policy)throw new Error('Missing privacy translation');
  policyArticle(next,policy);locale=next;copy=nextCopy;
  document.documentElement.lang=locale;document.title='Milo — '+policy.title;
  document.querySelector('[name="description"]').content=policy.description;
  for(const article of document.querySelectorAll('[data-policy-language]'))article.hidden=article.dataset.policyLanguage!==locale;
  for(const node of document.querySelectorAll('[data-policy-ui]'))node.textContent=policy[node.dataset.policyUi];
  document.querySelector('footer nav').setAttribute('aria-label',copy.legal);
  for(const node of document.querySelectorAll('[data-policy-aria]'))node.setAttribute('aria-label',policy[node.dataset.policyAria]);
  for(const link of document.querySelectorAll('[data-policy-home]'))link.href=localizedLink('./',locale);
  picker.value=locale;rememberLocale(locale);
 }catch{if(ticket===request){picker.value=locale;document.querySelector('#live-status').textContent=copy.languageError}}
}
picker.addEventListener('change',()=>setPolicyLocale(picker.value));
await setPolicyLocale(initialLocale());
