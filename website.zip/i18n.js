export const languages = Object.freeze([
  ['en','English'], ['tr','Türkçe'], ['de','Deutsch'], ['fr','Français'],
  ['es','Español'], ['es-AR','Español (Argentina)'], ['it','Italiano'],
  ['ja','日本語'], ['ko','한국어'], ['pt-PT','Português (Portugal)'],
  ['pt-BR','Português (Brasil)'], ['cs','Čeština']
]);
export const headlineKeys = new Set(['heroLine1','heroLine2','thingsTitle','roomTitle','companionTitle','faqTitle','closingTitle','miloNote','sceneNote']);
export function resolveLocale(value) {
  if (typeof value !== 'string') return null;
  const tag = value.trim().replaceAll('_','-').toLowerCase();
  const exact = languages.find(([code]) => code.toLowerCase() === tag);
  if (exact) return exact[0];
  const base = tag.split('-')[0];
  if (base === 'pt') return 'pt-PT';
  return languages.find(([code]) => code === base)?.[0] ?? null;
}
export function preferredLocale({query,stored,languages: browserLanguages = []}) {
  return resolveLocale(query) || resolveLocale(stored) || browserLanguages.map(resolveLocale).find(Boolean) || 'en';
}
export function initialLocale() {
  let stored;
  try { stored = localStorage.getItem('milo.site.locale'); } catch {}
  return preferredLocale({query:new URL(location.href).searchParams.get('lang'), stored, languages:navigator.languages || [navigator.language]});
}
const cache = new Map();
export async function loadCopy(locale) {
  if (!languages.some(([code]) => code === locale)) throw new Error('Unsupported language');
  if (!cache.has(locale)) {
    cache.set(locale, fetch(new URL(`./locales/${locale}.json`, import.meta.url)).then(response => {
      if (!response.ok) throw new Error('Language could not load');
      return response.json();
    }).catch(error => { cache.delete(locale); throw error; }));
  }
  return cache.get(locale);
}
export function rememberLocale(locale) {
  try { localStorage.setItem('milo.site.locale',locale); } catch {}
  const url=new URL(location.href);url.searchParams.set('lang',locale);
  history.replaceState(null,'',url.pathname+url.search+url.hash);
}
export function localizedLink(href,locale) {
  const url = new URL(href,location.href);
  if (url.origin === location.origin) url.searchParams.set('lang',locale);
  return url.href;
}
