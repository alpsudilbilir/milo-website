// One place to connect launch URLs after the domain and App Store release.
// The numeric Apple ID is verified in the App Store preparation record.
export const siteConfig = Object.freeze({
  appleID: '6761253333',
  appStoreListingURL: 'https://apps.apple.com/app/id6761253333',
  appStoreURL: null,
  privacyURL: 'privacy.html',
  termsURL: 'https://www.apple.com/legal/internet-services/itunes/dev/stdeula/'
});
