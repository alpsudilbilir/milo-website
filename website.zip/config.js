const appleID = '6761253333';
const appStoreListingURL = `https://apps.apple.com/app/id${appleID}`;

export const siteConfig = Object.freeze({
  appleID,
  appStoreListingURL,
  appStoreURL: appStoreListingURL,
  privacyURL: 'privacy.html',
  termsURL: 'https://www.apple.com/legal/internet-services/itunes/dev/stdeula/'
});
